Clayton Christensen

This project took longer than any previous project I have done. My biggest challenge was finding time to do the project. There was so much going on last 
week, between midterms and the pysics final on friday I never gave myself enough time to fully conceptualize how markov chains work. This led to me going
down a long rabbit hole of trying various methods of getting this working that were nowhere near as concise as the markov chain method. I surmounted this method
by using the last three of my slip days to finally sit down this saturday and work through the entire program. Saturday had nothing going on so I was able to
work through the kinks in my program and get it working, and there were a lot of kinks. I messed up on almost every part of this program in some way, from
the wrong substring setup to the improper use of sin.eof(). Time and focus were the solutions to these problems. I got a lot more comfortable with the c++ debuger
through this project and now know how to properly use it in order to find bugs. I disliked that we had a project due this close to our finals. I had to balance
working on this project and studying which was not a fun experience, although to be fair I could have definetly worked on it weeks before it was due so it is mostly
my fault. I liked that this project for all its difficulty, helped me learn how to properly use the debugger. I think this is a skill that is well worth the hours 
I spent working out all the problems that sprouted up in my code. I spent around 17 hours working on this project. This was mostly due to me only half focusing on
the work and half worrying about my physics final. I also had a lot of frusterating bugs that stumped me for hours on end. 
-Hope you all have an amazing summer, and good luck on your own finals.